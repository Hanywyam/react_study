import React from "react";
import Step1 from "./Step1";

const Main = () => {
  return (
    <div className="wrapper">
      <Step1 />
    </div>
  );
};

export default Main;
