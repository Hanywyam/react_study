import React from "react";

const Step1 = () => {
  return (
    <>
      <p>
        <label For="">이름</label>
        <input type="text" name="userName" id="userName" />
      </p>
    </>
  );
};

export default Step1;
